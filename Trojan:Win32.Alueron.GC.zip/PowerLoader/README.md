# PowerLoader
Power Loader botnet

Uploaded to GitHub for those want to analyse the code.
